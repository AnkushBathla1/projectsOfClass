package com.cg.bankingsystem.serviceDao;

public class TransactionDaoImpl {

}
