package com.cg.bankingsystem.exceptions;

public class InvalidDateOfBirthException extends Exception {

}
