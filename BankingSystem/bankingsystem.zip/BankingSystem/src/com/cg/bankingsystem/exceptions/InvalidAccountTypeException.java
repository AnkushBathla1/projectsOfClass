package com.cg.bankingsystem.exceptions;

public class InvalidAccountTypeException extends Exception{

}
