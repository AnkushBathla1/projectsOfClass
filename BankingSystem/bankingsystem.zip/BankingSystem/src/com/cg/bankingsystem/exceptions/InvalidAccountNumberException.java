package com.cg.bankingsystem.exceptions;

public class InvalidAccountNumberException extends Exception{

}
