package com.cg.bankingsystem.exceptions;

public class AccountBlockedException extends Exception{

}
