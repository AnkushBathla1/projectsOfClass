package com.cg.bankingsystem.exceptions;

public class InvalidPinNumberException extends Exception{

}
